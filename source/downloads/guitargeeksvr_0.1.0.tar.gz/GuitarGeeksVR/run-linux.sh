#!/usr/bin/env bash

cd `dirname $0`

java -Djava.library.path=native/linux \
     -Dorg.lwjgl.opengl.Window.undecorated=true \
     -Dloglevel=DEBUG \
     -XX:+UseConcMarkSweepGC \
     -jar GuitarGeeksVR.jar --uncapped

