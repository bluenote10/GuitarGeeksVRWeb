#!/usr/bin/env bash

cd `dirname $0`

java -Djava.library.path=native/macosx \
     -Dorg.lwjgl.opengl.Window.undecorated=true \
     -Dloglevel=DEBUG \
     -XX:+UseConcMarkSweepGC \
     -jar GuitarGeeksVR.jar --uncapped

